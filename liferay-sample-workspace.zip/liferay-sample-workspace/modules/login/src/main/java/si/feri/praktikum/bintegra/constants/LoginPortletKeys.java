package si.feri.praktikum.bintegra.constants;

/**
 * @author Jerman
 */
public class LoginPortletKeys {

	public static final String Login = "login";

}