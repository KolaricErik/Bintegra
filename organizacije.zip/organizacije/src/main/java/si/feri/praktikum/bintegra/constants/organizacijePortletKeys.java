package si.feri.praktikum.bintegra.constants;

/**
 * @author Jerman
 */
public class organizacijePortletKeys {

	public static final String organizacije = "organizacije";

}